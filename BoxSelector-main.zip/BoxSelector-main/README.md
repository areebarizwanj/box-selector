# BoxSelector
You can use this code anywhere, like in a game. where you want any box selection.
This code is in assembly language and it contains graphics too.
In this Box selector you can make any box of your choise. you have to put just box size and color according to instructions.
Instruction shows in the code.
